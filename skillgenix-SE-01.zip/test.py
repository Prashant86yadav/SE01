import json
import re
import os
from promptflow.core import tool
import openai

# Ensure your OpenAI API key is set in the environment
openai.api_key = os.getenv("OPENAI_API_KEY")

def repair_json(json_str: str) -> dict:
    """Repair common JSON issues in LLM output with multiple fallbacks"""
    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        print(f"JSON repair needed: {e}")

        # Attempt 1: Add missing closing quotes for unterminated strings
        if 'Unterminated string starting at' in e.msg:
            repaired = json_str[:e.pos] + '"' + json_str[e.pos:]
            try:
                return json.loads(repaired)
            except json.JSONDecodeError:
                pass

        # Attempt 2: Remove common truncation artifacts
        cleaned = re.sub(r'\(truncated[^)]*\)', '', json_str)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            pass

        # Attempt 3: Simple regex-based extraction as last resort
        try:
            headline = re.search(r'"headline":\s*"([^"]*)"', json_str)
            cover_image = re.search(r'"cover_image":\s*"([^"]*)"', json_str)
            body_match = re.search(r'"body":\s*"([\s\S]*?)"', json_str)

            references = []
            for match in re.finditer(r'\{\s*"url":\s*"([^\"]+)",\s*"summary":\s*"([^\"]+)"\s*\}', json_str):
                references.append({"url": match.group(1), "summary": match.group(2)})

            return {
                "headline": headline.group(1) if headline else None,
                "cover_image": cover_image.group(1) if cover_image else None,
                "body": body_match.group(1) if body_match else None,
                "references": references
            }
        except Exception as e2:
            print(f"Regex extraction failed: {e2}")
            return {
                "headline": None,
                "cover_image": None,
                "body": None,
                "references": []
            }

def beautify_with_gpt(article_data: dict) -> dict:
    """Use GPT to transform raw content into a well-formatted article"""
    system_msg = "You are an expert content editor specializing in UPSC exam preparation."
    user_prompt = (
        'Transform this UPSC exam preparation content into a well-structured article.\n'
        f'Title: {article_data.get("headline", "")}\n'
        f'Cover Image: {article_data.get("cover_image", "")}\n'
        f'Content: {article_data.get("body", "")}\n'
        'Requirements:\n'
        '1. Maintain all factual information\n'
        '2. Organize into logical sections with headings\n'
        '3. Use professional but accessible language\n'
        '4. Include all references with urls and summaries\n'
        '5. Output strictly as JSON with keys: title, cover_image, article, references\n'
        'Article body must include:\n'
        '- Introduction\n'
        '- Eligibility criteria\n'
        '- Exam pattern explanation\n'
        '- Preparation strategies\n'
        '- Conclusion'
    )

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.3,
            max_tokens=4000
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        print(f"GPT beautification failed: {e}")
        # Fallback to minimal structure
        return {
            "title": article_data.get("headline"),
            "cover_image": article_data.get("cover_image"),
            "article": article_data.get("body"),
            "references": article_data.get("references")
        }

@tool
def beautify_article(input1) -> dict:
    """Main function to process crawler output into a beautiful article"""
    # Prompt Flow may pass a list of runs; extract the first element if necessary
    if isinstance(input1, list) and len(input1) > 0:
        crawler_output = input1[0]
    else:
        crawler_output = input1 or {}

    # Attempt to extract the LLM analysis payload
    raw = None
    output_section = crawler_output.get("output")
    if isinstance(output_section, dict):
        # New format: nested under 'llm_analysis'
        raw = output_section.get("llm_analysis")
        # Fallback: direct fields under 'output'
        if raw is None and any(k in output_section for k in ("title","article","cover_image","references")):
            raw = output_section
    # If no raw payload, default to empty dict
    if raw is None:
        data = {}
    elif isinstance(raw, str):
        data = repair_json(raw)
    else:
        data = raw

    # Now beautify with GPT
    return beautify_with_gpt(data)
